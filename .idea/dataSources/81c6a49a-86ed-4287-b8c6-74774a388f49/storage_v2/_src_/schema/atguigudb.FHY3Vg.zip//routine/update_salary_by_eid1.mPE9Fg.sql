create
    definer = root@localhost procedure update_salary_by_eid1(IN emp_id int)
BEGIN
		DECLARE emp_salary DOUBLE;
		DECLARE time DOUBLE;
		SELECT salary INTO emp_salary
		FROM employees
		WHERE employee_id = emp_id;
		
		SELECT DATEDIFF(CURDATE(), hire_date)/365 INTO time
		FROM employees
		WHERE employee_id = emp_id;
		
		IF emp_salary < 8000 AND time > 5 THEN
				UPDATE employees
				SET salary = salary + 500
				WHERE employee_id = emp_id;
		END IF;
END;


create
    definer = root@localhost procedure show_someone_salary2(IN empname varchar(20), OUT empsalary double)
BEGIN
	SELECT salary INTO empsalary
	FROM employees
	WHERE last_name = empname;

END;


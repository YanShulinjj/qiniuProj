create
    definer = root@localhost procedure show_someone_salary(IN empname varchar(20))
BEGIN
	SELECT salary
	FROM employees
	WHERE last_name = empname;

END;


create
    definer = root@localhost procedure show_mgr_name(INOUT empname varchar(25))
BEGIN
	SELECT last_name INTO empname
	FROM employees
	WHERE employee_id = (
				SELECT manager_id
				FROM employees
				WHERE last_name = empname
	);

END;


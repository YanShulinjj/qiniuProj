create
    definer = root@localhost procedure selete_all_data()
BEGIN
	SELECT * FROM employees;

END;


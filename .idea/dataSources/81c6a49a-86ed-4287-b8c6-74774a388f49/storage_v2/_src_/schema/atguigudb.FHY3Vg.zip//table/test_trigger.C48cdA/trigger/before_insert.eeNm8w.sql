create definer = root@localhost trigger before_insert
    before insert
    on test_trigger
    for each row
    INSERT INTO test_trigger_log(t_log)
VALUES('insert one record!');


create definer = root@localhost view vu_avg_sal as
select `atguigudb`.`employees`.`department_id` AS `department_id`,
       avg(`atguigudb`.`employees`.`salary`)   AS `AVG(salary)`
from `atguigudb`.`employees`
where (`atguigudb`.`employees`.`department_id` is not null)
group by `atguigudb`.`employees`.`department_id`;


create
    definer = root@localhost procedure show_min_salary(OUT ms double)
BEGIN
	SELECT MIN(salary) INTO ms
	FROM employees;

END;


create
    definer = root@localhost procedure UpdateDataNoCondition3()
BEGIN
		#使用MySQL_error_code
		DECLARE Field_Not_Be_NULL CONDITION FOR 1048;
    #定义处理程序
    DECLARE CONTINUE HANDLER FOR Field_Not_Be_NULL SET @proc_value = -1;
    SET @x = 1;
    UPDATE employees SET email = NULL WHERE last_name = 'Abel';
    SET @x = 2;
    UPDATE employees SET email = 'aabbel' WHERE last_name = 'Abel';
    SET @x = 3;
END;


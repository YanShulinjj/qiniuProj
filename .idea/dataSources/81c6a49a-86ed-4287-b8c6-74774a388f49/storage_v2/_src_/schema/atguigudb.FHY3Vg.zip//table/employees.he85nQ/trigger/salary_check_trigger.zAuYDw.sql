create definer = root@localhost trigger salary_check_trigger
    before insert
    on employees
    for each row
BEGIN
		DECLARE mg_sal DOUBLE;
		SELECT salary INTO mg_sal FROM employees WHERE employee_id = NEW.manager_id;  # NEW 关键字表示新添加的记录。
		IF NEW.salary > mg_sal THEN
				SIGNAL SQLSTATE 'HY000' SET MESSAGE_TEXT = '薪资高于领导薪资错误';
		END IF;
END;

